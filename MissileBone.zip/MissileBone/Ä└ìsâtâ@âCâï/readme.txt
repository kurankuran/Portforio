Dash　　　　　　:[SPACE]
Pitch　　　　　 :[W][S]
Roll　　　　　　:[A][D]
Fire  Missile　 :[L]
Reload  Missile :[J]
AngleToF Missile:[I]
AngleToB Missile:[K]
Weapon Change   :[U][O]

********作成期間と時期*******
約2か月
********制作・設計概要*****
・制作はDirectX11で行いました。エフェクトの制作はEffekSeerを使用しています。

********アピールポイント*****
・ウェーブ式で敵配置を好きな位置に配置できるメソッドを作りました。
・敵の種類も継承を使うなどして簡単に用意できるようにしました。
・武器の種類を簡単に増やすことができるようにしました。
・ビルボードエフェクトの追加


********実行環境*******
Windous10
VisualStudio2017

