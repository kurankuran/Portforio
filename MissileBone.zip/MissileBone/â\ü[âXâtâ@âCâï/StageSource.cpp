//// �X�e�[�W�� [StageSphere.cpp]
//#include "StageSphere.h"
//#include "Scene.h"
//
//CStageSphere::CStageSphere(CScene* pScene) : CGameObj(pScene)
//{
//	SetID(GOT_STAGESPHERE);
//}
//
//CStageSphere::~CStageSphere()
//{
//
//}
//
//
//HRESULT CStageSphere::Init()
//{
//	HRESULT hr = S_OK;
//
//	SetRadius(10000.0f);
//	
//	return hr;
//}
//
//void CStageSphere::Update()
//{
//	CGameObj::Update();
//}